
#include "../includes/comandos.h"

/*
status nick(char* comando, pDatosMensaje datos);
status user(char* comando, pDatosMensaje datos);
status comandoVacio(char* comando, pDatosMensaje datos);
*/
