#ifndef COMANDOS_H
#define COMANDOS_H

#include "config.h"
#include "funciones_servidor.h"
/*
status nick(char* comando, pDatosMensaje datos);
status user(char* comando, pDatosMensaje datos);
status comandoVacio(char* comando, pDatosMensaje datos);
*/
#endif /* COMANDOS_H */
